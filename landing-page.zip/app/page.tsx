import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowRight, CheckCircle, Mail, MapPin, Phone } from "lucide-react"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <span>Resin & Design</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="#about" className="text-sm font-medium hover:text-primary">
              About
            </Link>
            <Link href="#services" className="text-sm font-medium hover:text-primary">
              Services
            </Link>
            <Link href="#portfolio" className="text-sm font-medium hover:text-primary">
              Portfolio
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:text-primary">
              Contact
            </Link>
          </nav>
          <Button>Book Consultation</Button>
        </div>
      </header>
      <main className="flex-1">
        <section className="relative">
          <div className="absolute inset-0 z-0">
            <Image
              src="/placeholder.svg?height=800&width=1600"
              alt="Elegant interior design with resin art accent piece"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-black/40" />
          </div>
          <div className="container relative z-10 py-24 md:py-32 lg:py-40 text-white">
            <div className="max-w-3xl space-y-5">
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
                Transform Your Space With Artful Design
              </h1>
              <p className="text-xl text-white/90">
                Elevate your interiors with our bespoke design services and unique resin art furniture pieces that blend
                functionality with artistic expression.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button size="lg" className="gap-2">
                  View Our Portfolio <ArrowRight className="h-4 w-4" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-transparent border-white text-white hover:bg-white/10"
                >
                  Book a Consultation
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section id="about" className="py-16 md:py-24 bg-gray-50">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Designer working on resin art piece"
                  width={800}
                  height={600}
                  className="rounded-lg shadow-lg"
                />
              </div>
              <div className="space-y-6">
                <h2 className="text-3xl font-bold tracking-tight">Our Design Philosophy</h2>
                <p className="text-lg text-muted-foreground">
                  Founded in 2015, Resin & Design has been creating stunning interior spaces and unique resin art
                  furniture that reflect our clients' personalities and lifestyles. We believe that every space tells a
                  story, and we're here to help you tell yours.
                </p>
                <div className="space-y-4">
                  {[
                    "Personalized design approach for each client",
                    "Sustainable and eco-friendly materials",
                    "Handcrafted resin art pieces",
                    "Seamless blend of functionality and aesthetics",
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle className="h-6 w-6 text-primary flex-shrink-0" />
                      <p>{item}</p>
                    </div>
                  ))}
                </div>
                <Button variant="outline" size="lg">
                  Learn More About Us
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="py-16 md:py-24">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Services</h2>
              <p className="text-lg text-muted-foreground">
                From complete interior transformations to custom resin art pieces, we offer a range of services to bring
                your vision to life.
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  title: "Interior Design",
                  description:
                    "Full-service interior design including space planning, color consultation, furniture selection, and project management.",
                },
                {
                  title: "Custom Resin Furniture",
                  description:
                    "Bespoke furniture pieces featuring our signature resin work, creating functional art for your home or office.",
                },
                {
                  title: "Resin Art Installations",
                  description:
                    "Statement wall art, decorative panels, and architectural elements created with our proprietary resin techniques.",
                },
                {
                  title: "Residential Design",
                  description:
                    "Transform your home with our comprehensive design services tailored to your lifestyle and preferences.",
                },
                {
                  title: "Commercial Spaces",
                  description:
                    "Create inspiring workplaces and commercial environments that reflect your brand and enhance productivity.",
                },
                {
                  title: "Design Consultation",
                  description:
                    "Expert advice on color schemes, layout optimization, and material selection for your DIY projects.",
                },
              ].map((service, i) => (
                <div key={i} className="bg-white p-8 rounded-lg shadow-sm border hover:shadow-md transition-shadow">
                  <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                  <p className="text-muted-foreground">{service.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="portfolio" className="py-16 md:py-24 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Portfolio</h2>
              <p className="text-lg text-muted-foreground">
                Explore our recent projects showcasing our interior design work and custom resin art furniture.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: "Azure Living Room",
                  category: "Interior Design",
                  image: "/placeholder.svg?height=400&width=600",
                },
                {
                  title: "Ocean Wave Dining Table",
                  category: "Resin Furniture",
                  image: "/placeholder.svg?height=400&width=600",
                },
                {
                  title: "Emerald Office Space",
                  category: "Commercial Design",
                  image: "/placeholder.svg?height=400&width=600",
                },
                {
                  title: "Sunset Resin Wall Art",
                  category: "Resin Art",
                  image: "/placeholder.svg?height=400&width=600",
                },
                {
                  title: "Minimalist Apartment",
                  category: "Residential Design",
                  image: "/placeholder.svg?height=400&width=600",
                },
                {
                  title: "River Coffee Table",
                  category: "Resin Furniture",
                  image: "/placeholder.svg?height=400&width=600",
                },
              ].map((project, i) => (
                <div key={i} className="group relative overflow-hidden rounded-lg">
                  <Image
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    width={600}
                    height={400}
                    className="w-full h-[300px] object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6 text-white">
                    <h3 className="text-xl font-bold">{project.title}</h3>
                    <p>{project.category}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="text-center mt-12">
              <Button size="lg">View All Projects</Button>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24 bg-[#1a3c34] text-white">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h2 className="text-3xl font-bold tracking-tight">Ready to transform your space?</h2>
                <p className="text-lg text-white/90">
                  Schedule a consultation with our design team to discuss your project and discover how we can bring
                  your vision to life with our interior design expertise and custom resin art.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button variant="secondary" size="lg">
                    Book a Consultation
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="bg-transparent border-white text-white hover:bg-white/10"
                  >
                    View Our Process
                  </Button>
                </div>
              </div>
              <div className="bg-white/10 p-8 rounded-lg">
                <h3 className="text-xl font-bold mb-4">Request Information</h3>
                <form className="space-y-4">
                  <Input
                    type="text"
                    placeholder="Full Name"
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
                  />
                  <Input
                    type="email"
                    placeholder="Email Address"
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
                  />
                  <Input
                    type="tel"
                    placeholder="Phone Number"
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
                  />
                  <select className="w-full rounded-md bg-white/10 border-white/20 text-white placeholder:text-white/60 p-2">
                    <option value="" className="bg-[#1a3c34]">
                      Select Service
                    </option>
                    <option value="interior-design" className="bg-[#1a3c34]">
                      Interior Design
                    </option>
                    <option value="resin-furniture" className="bg-[#1a3c34]">
                      Custom Resin Furniture
                    </option>
                    <option value="resin-art" className="bg-[#1a3c34]">
                      Resin Art Installations
                    </option>
                    <option value="consultation" className="bg-[#1a3c34]">
                      Design Consultation
                    </option>
                  </select>
                  <Button type="submit" variant="secondary" className="w-full">
                    Submit Request
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>

        <section id="testimonials" className="py-16 md:py-24">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Client Testimonials</h2>
              <p className="text-lg text-muted-foreground">
                Hear what our clients have to say about their experience working with our design team.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  name: "Emily Johnson",
                  location: "Modern Apartment, New York",
                  quote:
                    "The team at Resin & Design transformed our apartment into a stunning space that perfectly reflects our style. The custom resin dining table is now the centerpiece of our home!",
                },
                {
                  name: "Michael & Sarah Chen",
                  location: "Coastal Home, California",
                  quote:
                    "We couldn't be happier with our redesigned living space. The attention to detail and the beautiful resin art pieces have made our house truly unique and special.",
                },
                {
                  name: "Alexandra Rodriguez",
                  location: "Boutique Hotel Owner",
                  quote:
                    "Working with Resin & Design for our hotel lobby renovation was a fantastic experience. Their creative vision and custom furniture pieces have received countless compliments from our guests.",
                },
              ].map((testimonial, i) => (
                <div key={i} className="bg-gray-50 p-8 rounded-lg shadow-sm border">
                  <div className="flex flex-col h-full">
                    <div className="mb-4">
                      <svg className="h-6 w-6 text-primary" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                      </svg>
                    </div>
                    <p className="text-muted-foreground flex-1 mb-4">{testimonial.quote}</p>
                    <div>
                      <p className="font-bold">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Our Design Process</h2>
              <p className="text-lg text-muted-foreground">
                We follow a collaborative approach to ensure your vision comes to life exactly as you imagined.
              </p>
            </div>
            <div className="grid md:grid-cols-4 gap-8">
              {[
                {
                  step: "01",
                  title: "Consultation",
                  description:
                    "We begin with an in-depth consultation to understand your vision, preferences, and requirements.",
                },
                {
                  step: "02",
                  title: "Concept Development",
                  description:
                    "Our designers create detailed concepts and mood boards based on your input and our expertise.",
                },
                {
                  step: "03",
                  title: "Design & Creation",
                  description:
                    "Once the concept is approved, we begin the design process and creation of custom resin pieces.",
                },
                {
                  step: "04",
                  title: "Installation",
                  description:
                    "We handle the complete installation process, ensuring every detail is perfect before handover.",
                },
              ].map((process, i) => (
                <div key={i} className="relative p-6">
                  <div className="text-5xl font-bold text-primary/20 absolute -top-2 left-0">{process.step}</div>
                  <div className="pt-8">
                    <h3 className="text-xl font-bold mb-3">{process.title}</h3>
                    <p className="text-muted-foreground">{process.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="contact" className="py-16 md:py-24">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-6">
                <h2 className="text-3xl font-bold tracking-tight">Get in Touch</h2>
                <p className="text-lg text-muted-foreground">
                  Ready to start your design journey? Contact us today to schedule a consultation or visit our studio to
                  see our resin art and furniture collection in person.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-6 w-6 text-primary flex-shrink-0" />
                    <div>
                      <p className="font-medium">Our Studio</p>
                      <p className="text-muted-foreground">123 Design District, Suite 100, New York, NY 10001</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Mail className="h-6 w-6 text-primary flex-shrink-0" />
                    <div>
                      <p className="font-medium">Email Us</p>
                      <p className="text-muted-foreground">info@resinanddesign.com</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="h-6 w-6 text-primary flex-shrink-0" />
                    <div>
                      <p className="font-medium">Call Us</p>
                      <p className="text-muted-foreground">(212) 555-7890</p>
                    </div>
                  </div>
                </div>
                <div className="pt-4">
                  <h3 className="text-lg font-bold mb-2">Studio Hours</h3>
                  <p className="text-muted-foreground">Monday - Friday: 9:00 AM - 6:00 PM</p>
                  <p className="text-muted-foreground">Saturday: 10:00 AM - 4:00 PM (By Appointment)</p>
                  <p className="text-muted-foreground">Sunday: Closed</p>
                </div>
              </div>
              <div className="bg-gray-50 p-8 rounded-lg">
                <h3 className="text-xl font-bold mb-4">Send us a Message</h3>
                <form className="space-y-4">
                  <Input type="text" placeholder="Full Name" />
                  <Input type="email" placeholder="Email Address" />
                  <Input type="tel" placeholder="Phone Number" />
                  <select className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                    <option value="">How did you hear about us?</option>
                    <option value="referral">Referral</option>
                    <option value="social-media">Social Media</option>
                    <option value="search">Search Engine</option>
                    <option value="magazine">Magazine</option>
                    <option value="other">Other</option>
                  </select>
                  <textarea
                    className="min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder="Tell us about your project"
                  ></textarea>
                  <Button type="submit" className="w-full">
                    Send Message
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="bg-gray-900 text-gray-300">
        <div className="container py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-white">Resin & Design</h3>
              <p>Creating beautiful spaces and unique resin art furniture that inspire and delight.</p>
              <div className="flex space-x-4">
                {["facebook", "instagram", "pinterest", "houzz"].map((social) => (
                  <a
                    key={social}
                    href={`https://${social}.com`}
                    className="h-10 w-10 flex items-center justify-center rounded-full bg-gray-800 hover:bg-primary hover:text-white transition-colors"
                    aria-label={`Follow us on ${social}`}
                  >
                    <span className="sr-only">Follow us on {social}</span>
                    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm3 8h-1.35c-.538 0-.65.221-.65.778v1.222h2l-.209 2h-1.791v7h-3v-7h-2v-2h2v-2.308c0-1.769.931-2.692 3.029-2.692h1.971v3z" />
                    </svg>
                  </a>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Quick Links</h3>
              <ul className="space-y-2">
                {["Home", "About", "Services", "Portfolio", "Process", "Contact"].map((link) => (
                  <li key={link}>
                    <Link href="#" className="hover:text-white hover:underline">
                      {link}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Services</h3>
              <ul className="space-y-2">
                {[
                  "Interior Design",
                  "Custom Resin Furniture",
                  "Resin Art Installations",
                  "Residential Design",
                  "Commercial Spaces",
                  "Design Consultation",
                ].map((service) => (
                  <li key={service}>
                    <Link href="#" className="hover:text-white hover:underline">
                      {service}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Newsletter</h3>
              <p className="mb-4">
                Subscribe to our newsletter for design inspiration and updates on our latest projects.
              </p>
              <form className="space-y-2">
                <Input type="email" placeholder="Email address" className="bg-gray-800 border-gray-700" />
                <Button type="submit" className="w-full">
                  Subscribe
                </Button>
              </form>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800">
          <div className="container py-6 flex flex-col sm:flex-row justify-between items-center">
            <p>© {new Date().getFullYear()} Resin & Design. All rights reserved.</p>
            <div className="flex gap-4 mt-4 sm:mt-0">
              <Link href="#" className="text-sm hover:text-white hover:underline">
                Privacy Policy
              </Link>
              <Link href="#" className="text-sm hover:text-white hover:underline">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
